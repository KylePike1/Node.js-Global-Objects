// Print the current directoryto the console
console.log('Current directory: ' + process.cwd());

// Print the process version to the console
console.log('Current version: ' + process.version);

// Print the memory usage to the console
console.log('Memory Usage:', process.memoryUsage());